import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MyFrame1 extends Frame {
    public MyFrame1() {
        setTitle("Panels");
        setSize(300, 200);
        setLayout(null);  

        Panel mainPanel = new Panel();
        mainPanel.setLayout(null);  
        mainPanel.setBounds(20, 50, 550, 400);
        mainPanel.setBackground(Color.WHITE);
        add(mainPanel);

        Panel subPanelA = new Panel();
        subPanelA.setBounds(30, 30, 100, 100);
        subPanelA.setBackground(Color.BLUE);
        subPanelA.setName("subPanelA");

        Panel subPanelB = new Panel();
        subPanelB.setBounds(150, 30, 100, 100);
        subPanelB.setBackground(Color.RED);
        subPanelB.setName("subPanelB");

        mainPanel.add(subPanelA);
        mainPanel.add(subPanelB);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0); 
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new MyFrame1();
    }
}
